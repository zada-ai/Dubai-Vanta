const $ = (id) => document.getElementById(id);
const sleep = (ms) => new Promise((r) => setTimeout(r, ms));
const FIELDS = ["base", "catPath", "delay", "catSel", "prodSel", "nextSel"];

let stopFlag = false;
let categories = [];
const products = new Map();

function log(msg) {
  const el = $("log");
  el.value += msg + "\n";
  el.scrollTop = el.scrollHeight;
}
function stats() {
  $("stats").textContent = `Products scrape ho chuke hain: ${products.size}`;
}

// ---------- settings ----------
chrome.storage.local.get("settings", ({ settings }) => {
  if (settings) {
    if (settings.prodSel === "a[href*='product']") {
      settings.prodSel = "a[href*='/view/']";
    }
    FIELDS.forEach((f) => settings[f] !== undefined && ($(f).value = settings[f]));
  }
});

function saveSettings() {
  const s = {};
  FIELDS.forEach((f) => (s[f] = $(f).value));
  chrome.storage.local.set({ settings: s });
}

// ---------- fetch helpers ----------
async function getDoc(url) {
  const res = await fetch(url, { credentials: "include" });
  if (!res.ok) throw new Error(`HTTP ${res.status} ${url}`);
  if (/login|signin/i.test(new URL(res.url).pathname)) {
    throw new Error("Login nahi hai. Is browser mein arabiadropship.com par login karo.");
  }
  const html = await res.text();
  return { doc: new DOMParser().parseFromString(html, "text/html"), url: res.url };
}

// Fallback agar category page JS/AJAX se render hota ho
async function getRenderedLinks(url, selector) {
  return new Promise((resolve) => {
    chrome.tabs.create({ url, active: false }, (tab) => {
      const listener = (tabId, info) => {
        if (tabId === tab.id && info.status === "complete") {
          chrome.tabs.onUpdated.removeListener(listener);
          setTimeout(() => {
            chrome.scripting.executeScript(
              {
                target: { tabId: tab.id },
                func: (sel) => {
                  return [...document.querySelectorAll(sel)]
                    .map((a) => a.href)
                    .filter((h) => /\/view\/\d+/i.test(new URL(h).pathname));
                },
                args: [selector],
              },
              (results) => {
                chrome.tabs.remove(tab.id);
                resolve((results && results[0] && results[0].result) || []);
              }
            );
          }, 2500);
        }
      };
      chrome.tabs.onUpdated.addListener(listener);
    });
  });
}

const abs = (href, base) => {
  try {
    return new URL(href, base).href.split("#")[0];
  } catch {
    return "";
  }
};

// ---------- categories ----------
function findCategories(doc, pageUrl) {
  const sel = $("catSel").value.trim();
  const out = new Map();
  const anchors = sel ? doc.querySelectorAll(sel) : doc.querySelectorAll("a[href]");
  anchors.forEach((a) => {
    const text = a.textContent.replace(/\s+/g, " ").trim();
    const m = text.match(/\(\s*(\d+)\s*\)\s*$/);
    if (!sel && !m) return;
    const url = abs(a.getAttribute("href"), pageUrl);
    if (!url || url === pageUrl || url.startsWith("javascript")) return;
    const name = text.replace(/\(\s*\d+\s*\)\s*$/, "").trim() || url;
    if (!out.has(url)) out.set(url, { name, url, expected: m ? +m[1] : null });
  });
  return [...out.values()];
}

// ---------- listing pages ----------
function productLinks(doc, pageUrl) {
  const links = new Set();
  const sel = $("prodSel").value.trim() || "a[href*='/view/']";
  doc.querySelectorAll(sel).forEach((a) => {
    const u = abs(a.getAttribute("href"), pageUrl);
    if (!u) return;
    const p = new URL(u).pathname;
    if (!/\/view\/\d+/i.test(p)) return;
    links.add(u);
  });
  return links;
}

function nextLink(doc, pageUrl) {
  const sel = $("nextSel").value.trim();
  if (sel) {
    const a = doc.querySelector(sel);
    if (a && a.getAttribute("href") && !a.getAttribute("href").startsWith("javascript")) {
      return abs(a.getAttribute("href"), pageUrl);
    }
  }
  return null;
}

async function collectProducts(cat, delay) {
  const found = new Set();
  let url = cat.url;
  let page = 1;
  const visited = new Set();

  while (url && !stopFlag && page <= 300) {
    visited.add(url);
    const { doc, url: finalUrl } = await getDoc(url);
    let links = productLinks(doc, finalUrl);

    if (links.size === 0 && page === 1) {
      log(`  [${cat.name}] Static HTML mein links nahi mile, live browser tab check kar raha hoon...`);
      const sel = $("prodSel").value.trim() || "a[href*='/view/']";
      const liveLinks = await getRenderedLinks(finalUrl, sel);
      liveLinks.forEach((l) => links.add(l.split("#")[0]));
    }

    let added = 0;
    links.forEach((l) => {
      if (!found.has(l)) {
        found.add(l);
        added++;
      }
    });
    if (!added) break;

    let next = nextLink(doc, finalUrl);
    if (!next) {
      const u = new URL(cat.url);
      u.searchParams.set("page", ++page);
      next = u.href;
    } else {
      page++;
    }
    if (visited.has(next)) break;
    url = next;
    await sleep(delay);
  }
  return found;
}

// ---------- product page ----------
function extract(doc, url) {
  const q = (s) => doc.querySelector(s);
  const txt = (s) => {
    const e = q(s);
    return e ? e.textContent.replace(/\s+/g, " ").trim() : "";
  };
  const meta = (n) => (q(`meta[property="${n}"],meta[name="${n}"]`) || {}).content || "";

  let ld = {};
  doc.querySelectorAll('script[type="application/ld+json"]').forEach((s) => {
    try {
      const j = JSON.parse(s.textContent);
      const arr = Array.isArray(j) ? j : j["@graph"] || [j];
      arr.forEach((o) => {
        if (o && String(o["@type"]).includes("Product")) ld = o;
      });
    } catch {}
  });

  const offers = (Array.isArray(ld.offers) ? ld.offers[0] : ld.offers) || {};
  const body = doc.body ? doc.body.textContent.replace(/\s+/g, " ") : "";

  const images = new Set();
  [].concat(ld.image || [], meta("og:image") || []).forEach((i) => {
    if (i) images.add(abs(typeof i === "string" ? i : i.url, url));
  });
  doc.querySelectorAll("img").forEach((img) => {
    const src = img.getAttribute("src") || img.getAttribute("data-src") || img.getAttribute("data-lazy-src");
    if (!src || src.startsWith("data:")) return;
    if (/product|upload|storage|item|media/i.test(src) && !/logo|flag|icon|avatar/i.test(src)) {
      images.add(abs(src, url));
    }
  });

  let price = offers.price ? `${offers.price} ${offers.priceCurrency || ""}`.trim() : meta("product:price:amount") || txt('[class*="price"]');
  if (!price) {
    const pm = body.match(/AED\s*\d+(?:\.\d+)?/i);
    if (pm) price = pm[0].toUpperCase();
  }

  const shippingMatch = body.match(/Shipping Charges\s*(AED\s*\d+(?:\.\d+)?)/i);
  const returnMatch = body.match(/Return Charges\s*(AED\s*\d+(?:\.\d+)?)/i);

  const details = {};
  if (shippingMatch) details["Shipping Charges"] = shippingMatch[1];
  if (returnMatch) details["Return Charges"] = returnMatch[1];

  doc.querySelectorAll("table tr").forEach((tr) => {
    const c = tr.querySelectorAll("th,td");
    if (c.length === 2) details[c[0].textContent.trim()] = c[1].textContent.replace(/\s+/g, " ").trim();
  });

  return {
    title: ld.name || txt("h1") || txt("h2") || meta("og:title"),
    price: price,
    sku: ld.sku || txt('[class*="sku"]') || (body.match(/Sku\s*[:#]?\s*([A-Za-z0-9\-_.]+)/i) || [])[1] || "",
    stock: txt('[class*="stock"],[class*="availab"]') || (body.match(/(In Stock|Out of Stock)/i) || [])[1] || "",
    description: ld.description || txt('[class*="description"],#description') || meta("og:description"),
    images: [...images].filter(Boolean).join(" | "),
    details: JSON.stringify(details),
    url,
  };
}

// ---------- UI actions ----------
$("toggleAll").onclick = (e) => {
  e.preventDefault();
  const boxes = [...document.querySelectorAll("#cats input")];
  const anyUnchecked = boxes.some((b) => !b.checked);
  boxes.forEach((b) => (b.checked = anyUnchecked));
};

$("check").onclick = async () => {
  saveSettings();
  $("log").value = "";
  try {
    const { doc, url } = await getDoc(abs($("catPath").value, $("base").value));
    categories = findCategories(doc, url);
    if (!categories.length) {
      log("Koi category link nahi mila. 'Category link selector' mein selector dalo (F12 se dekh kar).");
      return;
    }
    log(`${categories.length} categories mili.`);
    $("cats").innerHTML = "";
    categories.forEach((c, i) => {
      const l = document.createElement("label");
      l.innerHTML = `<input type="checkbox" checked data-i="${i}"> ${c.name} ${c.expected !== null ? "(" + c.expected + ")" : ""}`;
      $("cats").appendChild(l);
    });
    $("catBox").style.display = "block";
    $("start").disabled = false;
  } catch (e) {
    log("Error: " + e.message);
  }
};

$("start").onclick = async () => {
  saveSettings();
  stopFlag = false;
  products.clear();
  $("start").disabled = true;
  $("stop").disabled = false;
  $("csv").disabled = $("json").disabled = true;
  const delay = Math.max(200, +$("delay").value || 800);
  const chosen = [...document.querySelectorAll("#cats input:checked")].map((c) => categories[+c.dataset.i]);

  for (const cat of chosen) {
    if (stopFlag) break;
    try {
      log(`\n[${cat.name}] products dhoond raha hoon...`);
      const links = await collectProducts(cat, delay);
      log(`[${cat.name}] ${links.size} product links mile` + (cat.expected !== null ? ` (site ke hisab se ${cat.expected})` : ""));
      for (const link of links) {
        if (stopFlag) break;
        if (products.has(link)) {
          const p = products.get(link);
          if (!p.categories.includes(cat.name)) p.categories += " | " + cat.name;
          continue;
        }
        try {
          const { doc, url } = await getDoc(link);
          products.set(link, { categories: cat.name, ...extract(doc, url) });
          stats();
        } catch (e) {
          log("  fail: " + link + " - " + e.message);
        }
        await sleep(delay);
      }
    } catch (e) {
      log(`[${cat.name}] error: ${e.message}`);
    }
  }
  log(`\nKhatam. Total ${products.size} unique products scrape hue.`);
  $("start").disabled = false;
  $("stop").disabled = true;
  $("csv").disabled = $("json").disabled = products.size === 0;
};

$("stop").onclick = () => {
  stopFlag = true;
  log("Stop kar raha hoon...");
};

function download(name, mime, data) {
  const a = document.createElement("a");
  a.href = URL.createObjectURL(new Blob([data], { type: mime }));
  a.download = name;
  a.click();
}
$("json").onclick = () => download("arabiadropship_products.json", "application/json", JSON.stringify([...products.values()], null, 2));
$("csv").onclick = () => {
  const rows = [...products.values()];
  const cols = ["categories", "title", "price", "sku", "stock", "description", "images", "details", "url"];
  const esc = (v) => `"${String(v ?? "").replace(/"/g, '""')}"`;
  const csv = [cols.join(","), ...rows.map((r) => cols.map((c) => esc(r[c])).join(","))].join("\r\n");
  download("arabiadropship_products.csv", "text/csv;charset=utf-8", "\ufeff" + csv);
};
